/*
 * io.c
 *
 *  Created on: 27.11.2020
 *      Author: Dominic Sonderegger, Jonas Augustin
 */

#include "board.h"  // library for the hardware
#include "lib/sseg_ctrl.h"  // library for 7seg display

