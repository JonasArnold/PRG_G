/*
 * sw11.c
 * Authors: Colin Bos, Dominic Sonderegger, Jonas Augustin, Jonas Arnold
 */


/* Bericht:
 *
 *
 *
 */

#include <stdio.h>

#include "board.h"
#include "io.h"
#include "calc.h"

int main(void) {
	init();

	// endless loop
	while(true){
		nextInput();  // io.h
		calculate();  // calc.h
	}  // end while true

	return 0;
}
