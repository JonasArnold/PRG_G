/*
 * calc.c
 *
 *  Created on: 27.11.2020
 *      Author: Colin Bos, Jonas Arnold
 */

#include "io.h"

void calculate(void){

}
