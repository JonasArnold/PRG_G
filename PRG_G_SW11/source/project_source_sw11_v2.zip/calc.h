/*
 * calc.h
 *
 *  Created on: 27.11.2020
 *      Author: Colin Bos, Jonas Arnold
 */

#ifndef CALC_H_
#define CALC_H_

#include "stack.h"
#include "io.h"

typedef int32_t num_t;

typedef enum{
	unknown, number, operator, error
} value_type_t;

typedef struct{
	value_type_t type;  // defines what the value is
	num_t value;
} element_t;

typedef enum{
	missing_operant, division_by_0, number_too_big
} calc_error_t;

// peeks the stack
// if the first element is a number => do nothing
// if the first element is an operator:
// -> pop the three newest elements from the stack:
//    1. operator ('+', '-', '*', '%' (ASCII))
//    2. operand 1 (integer number)
//    3. operand 2 (integer number)
// -> calculate the result
// -> push result as element_t onto the stack
// -> call displayResult
extern void calculate(void);

#endif /* CALC_H_ */
